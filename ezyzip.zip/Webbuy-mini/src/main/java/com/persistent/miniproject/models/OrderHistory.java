package com.persistent.miniproject.models;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

public class OrderHistory 
{
	private long order_id;
	Date pur_date;
	String status;
	List<String> productnames;
	HashMap<String, Integer> quantity;
	
	int total;
	public OrderHistory() {
		// TODO Auto-generated constructor stub
	}
	

	public HashMap<String, Integer> getQuantity() {
		return quantity;
	}
	public void setQuantity(HashMap<String, Integer> quantity) {
		this.quantity = quantity;
	}
	public long getOrder_id() {
		return order_id;
	}
	public void setOrder_id(long order_id) {
		this.order_id = order_id;
	}
	public Date getPur_date() {
		return pur_date;
	}
	public void setPur_date(Date pur_date) {
		this.pur_date = pur_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<String> getProductnames() {
		return productnames;
	}
	public void setProductnames(List<String> productnames) {
		this.productnames = productnames;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
}
