package com.persistent.miniproject.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.persistent.miniproject.models.CustomUserDetails;
import com.persistent.miniproject.models.Customer;
import com.persistent.miniproject.models.Secure;
import com.persistent.miniproject.repositories.CustomerDao;

public class CustomeUserDetailsService implements UserDetailsService {

	@Autowired
	private CustomerDao customerDao;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		System.out.println("emaillllllllll" + email);
		Customer customer = customerDao.findByEmail(email);
		if(customer == null) {
			System.out.println(" not found");

			throw new UsernameNotFoundException("User not found!!");
		}
		Secure.setId(customer.getId());
		System.out.println("found");
		return new CustomUserDetails(customer);
	}
	
	

}
