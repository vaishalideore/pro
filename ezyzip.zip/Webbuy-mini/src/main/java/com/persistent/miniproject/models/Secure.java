package com.persistent.miniproject.models;

public class Secure {
	
	private static long id;
	
	public static void setId(long cust_id) {
		id = cust_id;
	}
	public static long getId() {
		return id;
	}

}
