package com.persistent.miniproject.controllers;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import javax.servlet.http.HttpSession;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.persistent.miniproject.models.Product;
import com.persistent.miniproject.repositories.ProductDao;
import com.persistent.miniproject.services.SellerService;
import com.persistent.miniproject.services.CustomerService;
import com.persistent.miniproject.services.OrderDetailsService;
import com.persistent.miniproject.services.OrdersService;
import com.persistent.miniproject.services.ProductService;
import com.persistent.miniproject.models.Orders;
import com.persistent.miniproject.authetication.Authenticate;
import com.persistent.miniproject.models.Customer;
import com.persistent.miniproject.models.OrderDetails;


@Controller
public class SellerController 
{

	@Autowired
	SellerService service;
	
	@Autowired
	OrdersService orderService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	OrderDetailsService orderDetailsService;
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(path = "/addProduct", method = RequestMethod.GET)
	public String addProduct(Model model) {
		model.addAttribute("product", new Product());
		return "addProduct";
	}
	
	@RequestMapping(path = "/inventory", method = RequestMethod.GET)
	public String viewInventory(Model model,HttpSession session) {
		if(session.getAttribute("isAuthenticated").equals("true")) {
			if(session.getAttribute("type").equals("seller")) {
				List<Product> productsList = service.getAllProducts();
				model.addAttribute("productsList", productsList);
				List<String> ListOfCategories = service.getAllCategories();

				Collections.sort(ListOfCategories);
				
				model.addAttribute("ListOfCategories",ListOfCategories);
				return "sellerInventory";
			}
		}
		return "redirect:login";
	}
	
	@RequestMapping(path = "/addProduct", method = RequestMethod.POST)
	public String productEntry(@ModelAttribute Product product, BindingResult result) {
		service.addProduct(product);
		return "redirect:inventory";
	}
	
	@RequestMapping(path="/deleteProduct/{id}", method=RequestMethod.GET)
	public String removeProduct(@PathVariable("id") long id) {
		service.deleteProduct(id);
		return "redirect:../inventory";
	}
	
	@RequestMapping(path = "/updateProduct/{id}", method = RequestMethod.GET)
	public String productUpdate(@PathVariable("id") long id, Model model) {
		Product product = service.getProduct(id);
		model.addAttribute("product", product);
		return "updateProduct";
	}
	@RequestMapping(path = "/updateProduct/{product}", method = RequestMethod.POST)
	public String productUpdate2(@ModelAttribute Product product, BindingResult result) {
//		if(result.hasErrors()) {
//			return "redirect:updateProduct";
//		}
		service.addProduct(product);
		return "redirect:../inventory";
	}

	

	@RequestMapping("/order-details")
	public String orderDetails(Model model, 
			@ModelAttribute("quantity") ArrayList<Integer> quantities, 
			@ModelAttribute("products") ArrayList<Product> products, 
			@RequestParam("id") Long orderId) {
		
		//System.out.println("Order Id : " + orderId);
		Boolean isNotAvailable = false;
		
		model.addAttribute("isDisabled", "");
		
		quantities.addAll(orderDetailsService.getQuantityByOrderId(orderId));
		
		for(Integer quantity: quantities) {
			System.out.println(quantity);
		}
		
		List<Long> productIds = orderDetailsService.getProductIdsByOrderId(orderId);
		ArrayList<Integer> orderQuantities = orderDetailsService.getQuantityByOrderId(orderId);
		List<Boolean> stockList = new ArrayList<>();
		String status = orderDetailsService.getOrderStatusByOrderId(orderId);
		
		if(status.equals("rejected"))
			model.addAttribute("isDisabled", "disabled");
		
		for(int i = 0; i < productIds.size(); i++) {
			isNotAvailable = false;
			products.add(productService.getProductById(productIds.get(i)));
			
			
			Product product = productService.getProductById(productIds.get(i));
			
			if(product.getQuantity() >= orderQuantities.get(i)) {
				product.setQuantity(product.getQuantity() - orderQuantities.get(i));
			}
			else {
				System.out.println("Not available");
				isNotAvailable = true;
				model.addAttribute("isDisabled", "disabled");
				
			}
			
			stockList.add(isNotAvailable);
			
		}
		
		model.addAttribute("orderId", orderId);
		model.addAttribute("status", "Not Accepted");
		model.addAttribute("stockList", stockList);
		
		return "order_details";
	}
	
	
	
	
	@RequestMapping("/orders")
	public String orders(@ModelAttribute("orders") LinkedHashMap<Orders, Customer> orders,
			@ModelAttribute("status") ArrayList<String> status,
			HttpSession session) {
		
		if(session.getAttribute("isAuthenticated") != null) {
			System.out.println(Authenticate.authenticateUser(session));
			if(Authenticate.authenticateUser(session).equals("seller-dash")) {
				// TO fetch from database
				ArrayList<Orders> list1 = new ArrayList<>();
				ArrayList<Customer> list2 = new ArrayList<>();
				
				list1.addAll(orderService.getAllOrders());
				
				for(Orders order: list1) {
					list2.add(customerService.getCustomerById(order.getCust_id()));
					System.out.println(order.getId());
				}
				
				for(int i = 0; i < list1.size(); i++) {
					
					System.out.println(orderDetailsService.getOrderStatusByOrderId(i+1));
					System.out.println(i+1);
					String stat = orderDetailsService.getOrderStatusByOrderId(i+1);
					if(stat==null)
						continue;
					if(stat.equals("ordered")) {
						orders.put(list1.get(i), list2.get(i));
						status.add(stat.substring(0, 1).toUpperCase() + stat.substring(1));
					}	
				}
			
				return "seller-dash";
			}
		}
		
		return "redirect:/";
		
	}
	
	@RequestMapping("/acceptOrder")
	public String acceptOrder(Long orderid) {
		
		List<Long> productIds = orderDetailsService.getProductIdsByOrderId(orderid);
		ArrayList<Integer> orderQuantities = orderDetailsService.getQuantityByOrderId(orderid);
		String status = orderDetailsService.getOrderStatusByOrderId(orderid);
		
		if(status.equals("ordered")) {
			for(int i = 0; i < productIds.size(); i++) {
				Product product = productService.getProductById(productIds.get(i));
				if(product.getQuantity() >= orderQuantities.get(i)) {				
					System.out.println("Status : " + status);
					
					if(!(status.equals("accepted"))) {
						product.setQuantity(product.getQuantity() - orderQuantities.get(i));
						System.out.println(product.getQuantity());
						orderDetailsService.acceptOrderStatus(orderid);
						productService.updateProduct(product);
					}
				}
				else {
					System.out.println("Order can be rejected");
				}
			}
		}
		else {
			orderDetailsService.acceptOrderStatus(orderid);
		}
		
		
		return "redirect:orders";
	}
	
	@RequestMapping("/rejectOrder")
	public String rejectOrder (Long orderid) {
		orderDetailsService.rejectOrderStatus(orderid);
		return "redirect:orders";	
	}
	
	@RequestMapping(path = "/analysis", method = RequestMethod.GET)
	public String viewAnalalysisForm()
	{
		return "analysisForm";
	}
	@PostMapping("/analysis")
	public String viewAnalysisTable(@RequestParam("startDate") Date startDate,
									@RequestParam("endDate") Date endDate,
									Model model)
	{
		System.out.println(startDate);
		System.out.println(endDate);
		List<Orders> ordersList=orderService.getOrderBetweenDate(startDate, endDate);
		List<String> productNames=new ArrayList<String>();
		HashMap<String, Integer> productQuantityMap=new HashMap<String, Integer>();
		HashMap<String, Integer> productSaleMap=new HashMap<String, Integer>();
		
		if(ordersList!=null)
		{
			for(Orders o:ordersList)
			{
				int sale=0;
				List<OrderDetails> orderDetails=orderDetailsService.getAcceptedOrders(o.getId());
				for(OrderDetails a:orderDetails)
				{
					Product p=productService.getProductById(a.getProd_id());
					if(productNames.contains(p.getName()))
					{
						int tmp=productQuantityMap.get(p.getName());
						tmp+=a.getQuantity();
						productQuantityMap.put(p.getName(),tmp);
						tmp=tmp*Integer.parseInt(p.getPrice());
						productSaleMap.put(p.getName(), tmp);
					}
					else
					{
						productNames.add(p.getName());
						productQuantityMap.put(p.getName(), a.getQuantity());
						productSaleMap.put(p.getName(), a.getQuantity()*Integer.parseInt(p.getPrice()));
					}
				}
			}
			
		}
		model.addAttribute("quantityMap", productQuantityMap);
		model.addAttribute("saleMap", productSaleMap);
		model.addAttribute("productNames", productNames);
		return "analysisResult";
	}
}


