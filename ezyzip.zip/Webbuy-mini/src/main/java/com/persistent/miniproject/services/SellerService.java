package com.persistent.miniproject.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.persistent.miniproject.models.Product;
import com.persistent.miniproject.repositories.ProductDao;

@Service
public class SellerService {
	@Autowired
	ProductDao dao;
	public void addProduct(Product p) {
		dao.save(p);
	}
	public List<Product> getAllProducts(){
		return dao.findAll();
	}
	public void deleteProduct(long id) {
		Product p = dao.getOne(id);
		dao.delete(p);
	}
	public Product getProduct(long id) {
		return dao.getOne(id);
	}
	public List<String> getAllCategories(){
		return dao.findDistinctCategories();
	}

	
}
