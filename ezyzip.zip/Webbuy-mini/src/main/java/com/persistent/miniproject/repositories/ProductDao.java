

package com.persistent.miniproject.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.persistent.miniproject.models.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Long> 
{
	
	
	@Query(value=" Select * from Product where Category Like %category%", nativeQuery = true)
	List<Product> findByCategory(String category);
	
	Product findById(long id);
	@Query(value="SELECT DISTINCT CATEGORY FROM product",nativeQuery=true)
	List<String> findDistinctCategories();
	
	@Query(value="SELECT * FROM product where category = :category",nativeQuery=true)
	List<Product> findproductsbycategory(@Param("category") String category);
	
}
