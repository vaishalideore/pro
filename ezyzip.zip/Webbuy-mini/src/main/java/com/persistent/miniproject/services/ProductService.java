package com.persistent.miniproject.services;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.persistent.miniproject.models.OrderDetails;
import com.persistent.miniproject.models.Orders;
import com.persistent.miniproject.models.Product;
import com.persistent.miniproject.repositories.OrdersDao;
import com.persistent.miniproject.repositories.ProductDao;

@Service
public class ProductService {
	@Autowired
	private ProductDao productDao;

	public List<String> getcategory() {

	List<String> list = productDao.findDistinctCategories();
	System.out.println(list);
	
	return list;
}

public List<Product> getProduct(String category){
	
return productDao.findproductsbycategory(category);
}

	
	public void addProduct(Product product) {
		productDao.save(product);
	}
	
	public void updateProduct(Product product) {
		productDao.save(product);
	}
	
	public void deleteProductById(long id) {
		productDao.deleteById(id);
	}
	
	public Product getProductById(long id){
		return productDao.findById(id);
	}
	
	public List<Product> getAllProducts(){
		return productDao.findAll();
	}
	
	public List<Product> getProductByCategory(String category){
		List<Product> list= new ArrayList<>();
		list.addAll(productDao.findByCategory(category));
		
		return list;
	}
	
	public List<Product> getCartProducts(List<OrderDetails> list)
	{
		List<Product> productList=new ArrayList<Product>();
		for(int i=0; i<list.size(); i++)
		{
			System.out.println(list.get(i).getProd_id());
			Product p=productDao.findById(list.get(i).getProd_id());
		 	productList.add(p);	
		}
		return productList;
	}
	

}
