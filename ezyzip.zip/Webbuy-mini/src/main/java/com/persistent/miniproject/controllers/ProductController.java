package com.persistent.miniproject.controllers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.Order;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.persistent.miniproject.models.Customer;
import com.persistent.miniproject.models.OrderDetails;
import com.persistent.miniproject.models.Orders;
import com.persistent.miniproject.models.Product;
import com.persistent.miniproject.repositories.OrdersDao;
import com.persistent.miniproject.services.OrderDetailsService;
import com.persistent.miniproject.services.OrdersService;
import com.persistent.miniproject.services.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService service;

	@Autowired
	OrdersService orderService;

	@Autowired
	OrderDetailsService orderDetailService;

	@RequestMapping(path = "/customer-dash")
	public String displaycategory(Model model, HttpSession session) {
		System.out.println("in prod" + session.getAttribute("custid"));
//		if (session.getAttribute("isAuthenticated") == null) {
//			return "redirect:login";
//		}
//		if (!session.getAttribute("isAuthenticated").equals("true")) {
//			return "redirect:login";
//		}
//		if(!session.getAttribute("type").equals("customer"))
//		{
//			return "redirect:seller-dash";
//		}
		System.out.println("innnn");
		List<String> list = service.getcategory();
		model.addAttribute("list", list);
		System.out.println(list);
		return "customer-dash";
	}

	@RequestMapping(path = "/productlist", method = RequestMethod.GET)
	public String displayproducts(Model model, @RequestParam String category, HttpSession session) {
		
		if (session.getAttribute("isAuthenticated") == null) {
			return "redirect:login";
		}
		if (!session.getAttribute("isAuthenticated").equals("true")) {
			return "redirect:login";
		}
		if(!session.getAttribute("type").equals("customer"))
		{
			return "redirect:seller-dash";
		}
		System.out.println("sadf" + category);
		
		Map map = new HashMap();
		List<Product> productlistt = service.getProduct(category);
		model.addAttribute("list", productlistt);
		model.addAttribute("cartvalue", "add to cart");
		for (Product p : productlistt) {
			if (p.getQuantity() < 1) {
				map.put(p.getId(), "O");
				continue;
			}
			System.out.println();
			Orders o = orderService.getCart((long) session.getAttribute("custid"));

			if (o != null) {
				OrderDetails od = orderDetailService.getIfInCart(o.getId(), p.getId());
				if (od == null) {
					// add to cart
					map.put(p.getId(), "T");
				} else {
					map.put(p.getId(), "F");
				}
			} else {
				map.put(p.getId(), "T");
			}
		}
		model.addAttribute("map", map);
		System.out.println(map);
		return "productlist";
	}

	@RequestMapping(path = "/addToCart", method = RequestMethod.GET)
	public String addToCartt(@RequestParam String category, @RequestParam long id, HttpSession session,
			RedirectAttributes redirectAttrs) {

		if (session.getAttribute("isAuthenticated") == null) {
			return "redirect:login";
		}
		if (!session.getAttribute("isAuthenticated").equals("true")) {
			return "redirect:login";
		}

		session.setAttribute("cart", "true");
		System.out.println(id + category);
		orderService.addToCart(id, session);
		redirectAttrs.addAttribute("category", category);
		return "redirect:productlist?category={category}";
	}
}