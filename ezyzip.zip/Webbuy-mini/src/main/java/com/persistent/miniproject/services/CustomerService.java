package com.persistent.miniproject.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.persistent.miniproject.models.Customer;
import com.persistent.miniproject.models.Login;
import com.persistent.miniproject.repositories.CustomerDao;

@Service
public class CustomerService 
{
	@Autowired
	CustomerDao dao;
	
	public void addCustomer(Customer c)
	{
		dao.save(c);
	}
	
	public Customer authenticate(Login log)
	{
		Customer c=dao.findByEmail(log.getEmail());
		if(c==null)
			return null;
		else
		{
			if(log.getPassword().equals(c.getPassword()))
				return c;
			else
				return null;
		}
		
	}
	
	public Customer getCustomerById(Long id) {
		return dao.findById(id).get();
	}
}
