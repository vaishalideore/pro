package com.persistent.miniproject.services;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.persistent.miniproject.models.OrderDetails;
import com.persistent.miniproject.models.Orders;
import com.persistent.miniproject.repositories.OrdersDao;


@Service
public class OrdersService {
	@Autowired
	OrderDetailsService orderservices = new OrderDetailsService();
	
	@Autowired
    private OrdersDao orderDao;
	
	
	public void addOrder(Orders order) {
		orderDao.save(order);
	}
	
	public void deleteOrder(Long id) {
		orderDao.deleteById(id);
	}
	
	public Orders getOrderById(Long id) {
		return orderDao.findById(id).get();
	}
	
	public void updateOrder(Orders order) {
		orderDao.save(order);
	}
	
	public List<Orders> getByCustomerId(Long custId){
		return orderDao.findByCustId(custId);
	}
	
	public List<Orders> getAllOrders(){
		return orderDao.findAllOrders();
	}
	public Orders getCart(long id)
	{
		return orderDao.findNullPurDate(id);
	}
	
	
	public void addToCart(long id,HttpSession session) {
		long previd =0;
		
	
		System.out.println(id);
		//
		Orders o1 = orderDao.findNullPurDate((long)session.getAttribute("custid"));
		if(o1 != null) {	
			if(o1.getId()>0) {
				previd = o1.getId();
				System.out.println("previous id 2"+previd);
				
			}
			else {
				System.out.println("abc");
				Orders orders = new Orders();
				long cid=(long) session.getAttribute("custid");
				orders.setCust_id(cid);
				orders.setSeller_id(0);
			    orderDao.save(orders);
			    previd = orderDao.findhighestID();
			    System.out.println("previous id 1"+previd);
			}
		}
		else {
			System.out.println("xyz");
			Orders orders = new Orders();
			long cid=(long) session.getAttribute("custid");
			orders.setCust_id(cid);
			orders.setSeller_id(0);
		    orderDao.save(orders);
		    previd = orderDao.findhighestID();
		    System.out.println("previous id 1"+previd);
		}
		
		
		
		
		//id always getting zero
		
		//fill the orderdetails table
		OrderDetails orderdetails = new OrderDetails();
		orderdetails.setOrder_id(previd);
		orderdetails.setProd_id(id);
		orderdetails.setQuantity(1);
		orderdetails.setStatus("added to cart");
		System.out.println("end");
		orderservices.addToOrderDetails(orderdetails);
		
	}
	
	public void removeById(long id)
	{
		orderDao.deleteById(id);
	}
	
	public List<Orders> getCustomerHistory(long id)
	{
		return orderDao.findCustHist(id);
	}
	
	public List<Orders> getOrderBetweenDate(Date start, Date end)
	{
		return orderDao.findOrdersBetweenDates(start, end);
	}
	
}
