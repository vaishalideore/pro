package com.persistent.miniproject.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.persistent.miniproject.authetication.Authenticate;
import com.persistent.miniproject.models.Customer;
import com.persistent.miniproject.models.Login;
import com.persistent.miniproject.models.Secure;
import com.persistent.miniproject.services.CustomerService;

@Controller
public class MainController 
{
	@Autowired
	CustomerService custService;
	
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String showMainPage(HttpSession session) {
		String url = Authenticate.authenticateUser(session);
		if(url.equals("/"))
			return "landing";
		else
   		return url;
			
	}
	
	
//	@RequestMapping(path = "/login", method = RequestMethod.GET)
//	public String showLogInPage(Model model,HttpSession session)
//	{
//		
//		if((session.getAttribute("isAuthenticated")) != null) {
//			System.out.println(Authenticate.authenticateUser(session));
//			return Authenticate.authenticateUser(session);
//		}
//		
//		Login login=new Login();
//		model.addAttribute(login);
//		return "login";
//	}
//	
	
	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String showRegisterPage(Model model, HttpSession session)
	{
		if(session!=null)
		{
			if(session.getAttribute("isAuthenticated") != null) {
				if(session.getAttribute("isAuthenticated").equals("true"))
				{
					if(session.getAttribute("type").equals("customer"))
						return "welcome";
					else 
						return "seller-dash";
				}
			}

		}
		
		model.addAttribute("cust",new Customer());
		return "register";
	}
	
	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public String registerCustomer(@ModelAttribute Customer cust, BindingResult result)
	{
		if(result.hasErrors())
			return "register";
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		cust.setPassword(encoder.encode(cust.getPassword()));
		System.out.println("reg "+cust.getPassword());
		custService.addCustomer(cust);
		
		return "redirect:/";
	}
	
	@RequestMapping(path = "/try")
	public String registerCustomer(HttpSession session)
	{
		session.setAttribute("isAuthenticated", "true");
		session.setAttribute("type", "customer");
		session.setAttribute("custid",(long) Secure.getId());
		System.out.println("in try");
		return "redirect:customer-dash";
	}
	
//	@RequestMapping(path = "/login", method = RequestMethod.POST)
//	public String authentication(@ModelAttribute Login login, BindingResult result, HttpSession session)
//	{
//			if(result.hasErrors())
//				return "login";
//			
//		
//				if(login.getType().equals("customer")) {
//					Customer auth=custService.authenticate(login);
//					if(auth!=null) {
//						session.setAttribute("isAuthenticated", "true");
//						session.setAttribute("type", "customer");
//						session.setAttribute("custid",(long) auth.getId());
//						return "redirect:customer-dash";
//					}
//						
//					else {
//						return "redirect:login";
//					}
//				}
//			
//			else if(login.getType().equals("seller")) 
//			{	
//				if(login.getEmail().equals("seller@gmail.com")) {
//
//						if(login.getPassword().equals("admin"))
//						{
//							session.setAttribute("isAuthenticated", "true");
//							session.setAttribute("type", "seller");
//							return "redirect:orders";
//						} 
//					}
//				else
//					return "redirect:login";
//			
//			
//			}
//			return "redirect:login";
//	}
	
	@RequestMapping(path = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session)
	{
		if(session.getAttribute("isAuthenticated") == null)
				return "redirect:/";
		
		session.removeAttribute("isAuthenticated");
		if(session.getAttribute("type").equals("customer"))
		{
			session.removeAttribute("custid");
		}
		session.removeAttribute("type");
		session.invalidate();
		return "redirect:login";
	}
}
