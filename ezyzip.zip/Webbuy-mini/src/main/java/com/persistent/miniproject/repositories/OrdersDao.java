package com.persistent.miniproject.repositories;

import java.sql.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.persistent.miniproject.models.Orders;

@Repository
public interface OrdersDao extends JpaRepository<Orders, Long> 
{	
	@Query(value="SELECT * FROM orders WHERE cust_id=cust_Id", nativeQuery=true)
	public List<Orders> findByCustId(Long cust_Id);
	
	@Query(value="SELECT * FROM orders ORDER BY pur_date", nativeQuery=true)
	public List<Orders> findAllOrders();
	

	@Query(value="SELECT last_insert_id() ",nativeQuery=true)
	public int findhighestID();

	@Query(value="SELECT * FROM orders WHERE pur_date is NULL and cust_id = ?1", nativeQuery=true)
	public Orders findNullPurDate(long cust_Id);
	
	@Query(value="SELECT * FROM orders WHERE cust_id=:cust_Id and pur_date is not null ORDER BY pur_date DESC", nativeQuery=true)
	public List<Orders> findCustHist(long cust_Id);
	
	@Query(value="SELECT * FROM orders WHERE pur_date BETWEEN :start AND :end", nativeQuery=true)
	public List<Orders> findOrdersBetweenDates(Date start, Date end);
	
}
