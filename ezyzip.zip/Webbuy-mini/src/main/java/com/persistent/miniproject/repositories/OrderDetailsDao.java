package com.persistent.miniproject.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.persistent.miniproject.models.OrderDetails;
@Repository
public interface OrderDetailsDao extends JpaRepository<OrderDetails, Long> 
{
	
	@Query(value="Select prod_id from order_details where order_id = ?1", nativeQuery=true)
	List<Long> findByOrderId(Long order_Id);
	
	@Query(value="Select distinct status from order_details where order_id = ?1", nativeQuery=true)
	String findStatusByOrderId(Long order_Id);
	
	@Modifying
	@Transactional
	@Query(value="Update order_details set status = ?2 where order_id = ?1", nativeQuery=true)
	void setOrderStatus(Long order_Id, int status);
	
	@Query(value="select * from order_details where order_id = ?1 and status='added to cart'", nativeQuery=true)
	public List<OrderDetails> getAddedToCart(long order_Id);

	public OrderDetails findById(long id);
	
	@Query(value="SELECT order_id from order_details where id = ?1", nativeQuery=true)
	public long getOrderId(long id);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE order_details set status='ordered' where id = ?1", nativeQuery=true)
	public void updateStatusToOrdered(long id);


	@Query(value="Select quantity from order_details where order_id = ?1", nativeQuery=true)
	public ArrayList<Integer> findQuantityByOrderId(Long order_Id);

	@Query(value="select order_id from order_details where prod_id = :prod_id and order_id in (select id from orders where cust_id = :cust_id and pur_date = NULL ))", nativeQuery=true)
	public long findorderid(long prod_id,long cust_id);
	
	@Modifying
	@Transactional
	@Query(value="delete from order_details  where prod_id = :prod_id and order_id in (select id from orders where cust_id = :cust_id and pur_date = NULL) )", nativeQuery=true)
	public void deleteOrderDetails(long prod_id,long cust_id);

	@Query(value="select * from order_details where prod_id = ?2 and order_id = ?1", nativeQuery=true)
	OrderDetails getIfInCartDao(long orderid,long prodid);
	
	@Query(value="SELECT * FROM order_details where order_id = ?1", nativeQuery=true)
	List<OrderDetails> findOrderDetailsByOrderId(long id);
	
	@Query(value="SELECT * FROM order_details where order_id = ?1 and status <> 'added to cart'", nativeQuery=true)
	List<OrderDetails> findOrderDetailsHistory(long orderId);
	
	@Query(value="SELECT * FROM order_details where order_id = ?1 AND status='accepted'", nativeQuery=true)
	List<OrderDetails> findAcceptedOrderDetails(long orderId);

}
