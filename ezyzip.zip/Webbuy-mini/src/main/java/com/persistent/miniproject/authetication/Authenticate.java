package com.persistent.miniproject.authetication;

import javax.servlet.http.HttpSession;

public class Authenticate {
	
	public static String authenticateUser(HttpSession session) {
		if(session.getAttribute("isAuthenticated") != null) {
			if(session.getAttribute("isAuthenticated").equals("true")) {
				if(((String)session.getAttribute("type")).equals("seller")) {
					return "seller-dash";
				}
				else if(((String)session.getAttribute("type")).equals("customer")) {
					return "redirect:customer-dash";
				}
			}
		}
		
		return "/";
	}
	
}
