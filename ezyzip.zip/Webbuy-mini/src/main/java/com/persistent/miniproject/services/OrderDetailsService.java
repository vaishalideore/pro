package com.persistent.miniproject.services;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.persistent.miniproject.models.OrderDetails;
import com.persistent.miniproject.repositories.OrderDetailsDao;

@Service
public class OrderDetailsService {
	@Autowired
	private OrderDetailsDao orderDetailsDao;
	@Autowired
	private OrdersService orderService;
	
	public List<Long> getProductIdsByOrderId(long orderId) {
		List<Long> productIds = orderDetailsDao.findByOrderId(orderId);
		return productIds;
	}
	
	public String getOrderStatusByOrderId(long orderId) {
		return orderDetailsDao.findStatusByOrderId(orderId);
	}
	
	public ArrayList<Integer> getQuantityByOrderId(long orderId) {
		return orderDetailsDao.findQuantityByOrderId(orderId);
	}
	
	public void acceptOrderStatus(Long orderId) {
		orderDetailsDao.setOrderStatus(orderId, 3);
	}
	
	public void rejectOrderStatus(Long orderId) {
		orderDetailsDao.setOrderStatus(orderId, 4);
	}
	
	public List<OrderDetails> getCurrentCart(long id)
	{
		return orderDetailsDao.getAddedToCart(id);
	}
	
	public void addToOrderDetails(OrderDetails orderdetails) {
		orderDetailsDao.save(orderdetails);
	}
	public OrderDetails findOrderDetailsById(long id)
	{
		return orderDetailsDao.findById(id);
	}
	public void updateQuantity(OrderDetails orderDetails)
	{
		orderDetailsDao.save(orderDetails);
	}
	public void removeById(long id)
	{
		orderDetailsDao.deleteById(id);
	}
	public long getOrderId(long id)
	{
		return orderDetailsDao.getOrderId(id);
	}
	public void changeStatusToOrdered(long id)
	{
		orderDetailsDao.updateStatusToOrdered(id);
	}
	
	public  OrderDetails getIfInCart(long orderid , long prodid) {
		return orderDetailsDao.getIfInCartDao(orderid,prodid);
	}
	
	public void deleteFromCart(long id,HttpSession session) {
		long productId = id;
		System.out.println("first answer" + productId);
		//long orderid = orderDetailsDao.findorderid(productId,session.getAttribute("custid") );
		//System.out.println("answers"+orderid);
		//orderDetailsDao.deleteOrderDetails(productId ,session.getAttribute("custid"));
		//orderService.deleteOrder(orderid);
		
	}
	public List<OrderDetails> getListByOrderId(long id)
	{
		return orderDetailsDao.findOrderDetailsByOrderId(id);
	}
	public List<OrderDetails> getOrderDetailsHistory(long orderId)
	{
		return orderDetailsDao.findOrderDetailsHistory(orderId);
	}
	public List<OrderDetails> getAcceptedOrders(long orderId)
	{
		return orderDetailsDao.findAcceptedOrderDetails(orderId);
	}
}
	