package com.persistent.miniproject.controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.persistent.miniproject.models.OrderDetails;
import com.persistent.miniproject.models.OrderHistory;
import com.persistent.miniproject.models.Orders;
import com.persistent.miniproject.models.Product;
import com.persistent.miniproject.services.OrderDetailsService;
import com.persistent.miniproject.services.OrdersService;
import com.persistent.miniproject.services.ProductService;

@Controller
public class CustomerController 
{
	@Autowired
	OrdersService ordersService;
	
	@Autowired
	OrderDetailsService orderDetailService;
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(path = "/cart", method = RequestMethod.GET)
	public String viewCart(Model model, HttpSession session)
	{
		if(session !=null)
		{
			if(session.getAttribute("isAuthenticated")!=null)
			if(session.getAttribute("isAuthenticated").equals("true")) 
			{
				if(session.getAttribute("type").equals("customer")) 
				{
					long cid=(long)session.getAttribute("custid");
					
					
					Orders order=ordersService.getCart(cid);
					if(order!=null)
					{
						long orderid=order.getId();
						System.out.println(orderid);
						
						List<OrderDetails> addToCart=orderDetailService.getCurrentCart(orderid);
						System.out.println(addToCart.size());
						
						List<Product> listOfProducts=productService.getCartProducts(addToCart);
						model.addAttribute("orderDetailsList", addToCart);
						model.addAttribute("productList", listOfProducts);
						model.addAttribute("cartSize", listOfProducts.size());
					}
					return "cart";
				}
				else
					return "redirect:orders";
			}
			else
				return "redirect:login";
		}
		
		return "redirect:login";
	}
	
	@RequestMapping(path = "/incrementCartProduct/{productInCartID}", method = RequestMethod.GET)
	public String incrementProductInCart(@PathVariable("productInCartID") long productInCartID)
	{
		System.out.println("To increment the quantity of orderDetails ID : "+productInCartID);
		OrderDetails orderDetails=orderDetailService.findOrderDetailsById(productInCartID);
		int quantity=orderDetails.getQuantity();
		Product product=productService.getProductById(orderDetails.getProd_id());
		if(product.getQuantity()>quantity)
		{
			quantity++;
			orderDetails.setQuantity(quantity);
			orderDetailService.updateQuantity(orderDetails);
		}
		return "redirect:../cart";
	}
	@RequestMapping(path = "/decrementCartProduct/{productInCartID}", method = RequestMethod.GET)
	public String decrementProductInCart(@PathVariable("productInCartID") long productInCartID)
	{
		System.out.println("To decrement the quantity of orderDetails ID : "+productInCartID);
		OrderDetails orderDetails=orderDetailService.findOrderDetailsById(productInCartID);
		int quantity=orderDetails.getQuantity();
		if(quantity!=1)
		{
			quantity--;
			orderDetails.setQuantity(quantity);
			orderDetailService.updateQuantity(orderDetails);
		}
		return "redirect:../cart";
	}
	@RequestMapping(path = "/deleteCartProduct/{productInCartID}/{cartSize}", method = RequestMethod.GET)
	public String deleteProductInCart(@PathVariable("productInCartID") long productInCartID, @PathVariable("cartSize") int cartSize)
	{
		System.out.println("To deleting orderDetails with ID : "+productInCartID);
		System.out.println("Cart Size "+cartSize);
		OrderDetails orderDetails=orderDetailService.findOrderDetailsById(productInCartID);
		if(cartSize==1)
		{
			long id=orderDetailService.getOrderId(productInCartID);
			orderDetailService.removeById(productInCartID);
			ordersService.removeById(id);
			
		}
		else
		{
			orderDetailService.removeById(productInCartID);
		}
		return "redirect:../../cart";
	}
	
	@RequestMapping(path = "/checkout/{orderIds}", method = RequestMethod.GET)
	public String checkout(@PathVariable("orderIds") String ids)
	{
		String[] idArray=ids.split(",");
		OrderDetails orderDetails=null;
		//0th index is empty
		for(int i=1; i<idArray.length; i++)
		{
		System.out.println("Changing status to Ordered in order_details table");
			orderDetails=orderDetailService.findOrderDetailsById(Long.parseLong(idArray[i]));			
			System.out.println("OrderDetails id found : "+orderDetails.getId());
			orderDetailService.changeStatusToOrdered(orderDetails.getId());
		}
		if(orderDetails!=null)
		{
			Orders order=ordersService.getOrderById(orderDetails.getOrder_id());
			long millis=System.currentTimeMillis();  
			Date date=new Date(millis);
			order.setPur_date(date);
			ordersService.updateOrder(order);			
			return "success";
		}
		else
		{
			return "redirect:../cart";
		}
		
	}
	@RequestMapping(path = "/checkout", method = RequestMethod.GET)
	public String emptyCheckout()
	{
		return "redirect:cart";
	}
	
	@RequestMapping(path = "/customerHistory", method = RequestMethod.GET)
	public String viewOrderHistory(Model model, HttpSession session)
	{
		if(session!=null)
		{
			if(session.getAttribute("isAuthenticated").equals("true"))
			{
				if(session.getAttribute("type").equals("customer"))
				{
					List<OrderDetails> orderDetailsList=new ArrayList<OrderDetails>();
					List<OrderHistory> orderHistoryList=new ArrayList<OrderHistory>();
					OrderHistory hist=null;
					List<Orders> orders=ordersService.getCustomerHistory((long)session.getAttribute("custid"));
					
					for(int i=0; i<orders.size(); i++)
					{
						hist=new OrderHistory();
						
						List<OrderDetails> list=orderDetailService.getOrderDetailsHistory(orders.get(i).getId());
						hist.setOrder_id(orders.get(i).getId());
						hist.setPur_date(orders.get(i).getPur_date());
						orderDetailsList.addAll(list);
						List<String> productnames=new ArrayList<String>(); 
						HashMap<String, Integer> quantity=new HashMap<String, Integer>(); 
						int total=0;
						String status=null;
						for(OrderDetails o:list)
						{
							Product tmp=productService.getProductById(o.getProd_id());
							total+=o.getQuantity()*Integer.parseInt(tmp.getPrice());
							productnames.add(tmp.getName());
							quantity.put(tmp.getName(), o.getQuantity());
							status=o.getStatus();
						}
						hist.setProductnames(productnames);
						hist.setQuantity(quantity);
						hist.setTotal(total);
						hist.setStatus(status);
						orderHistoryList.add(hist);
					}
					model.addAttribute(orderHistoryList);
					List<String> statusList= new ArrayList<String>();
					statusList.add("ordered");
					statusList.add("accepted");
					statusList.add("rejected");
					model.addAttribute("statusList",statusList);
					return "customerHistory";
				}
				else
					return "redirect:seller-dash";
			}
			
		}
		return "redirect:login";
	}
} 
